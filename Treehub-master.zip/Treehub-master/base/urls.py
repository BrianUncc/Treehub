from django.urls import path
from . import views
from .views import CustomLogoutView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.home, name="home"),
    path('homepage/', views.homepage, name="homepage"),
    path('virtualpractice/', views.virtualpractice, name="virtualpractice"),
    path('progress/', views.progress, name="progress"),
    path('about/', views.about, name="about"),
    path('messages/', views.custom_messages_view, name='messages'),
    path('profile/', views.profile_view, name='profile'),
    path('view_profile/', views.view_profile, name='view_profile'),  # 确保这个路径存在

    # Authentication URLs
    path('login/', views.login_view, name="login"),
    path('logout/', CustomLogoutView.as_view(), name="logout"),
    path('signup/', views.signup, name="signup"),

    # Custom Password Reset with Security Question
    path('password_reset/', views.password_reset_username, name="password_reset"),
    path('password_reset/security_question/', views.password_reset_security_question, name="password_reset_security_question"),
    path('password_reset/confirm/', views.password_reset_confirm, name="password_reset_confirm"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)